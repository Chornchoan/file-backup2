 <footer>This is my footer</footer>

 </body>

 </html>