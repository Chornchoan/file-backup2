<?php

// TODO include the header
require_once('templates/header.php');


// TODO include the home
require_once('pages/home.php');

// TODO include the footer
require_once('templates/footer.php');
