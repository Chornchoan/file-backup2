<?php

// TODO include the header

// TODO include the home

// TODO include the footer
