<?php 
// include of header

// include navbar

//  include of pages 

//  include of footer 



