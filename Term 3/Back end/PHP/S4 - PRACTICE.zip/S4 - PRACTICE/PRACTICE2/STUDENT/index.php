
<?php 
// include of header

//  include of pages 

//  include of footer 



