<div class="container">
    <h1>Home Page</h1>
    <div class="container">
    <h1>Home Page</h1>
    <div class="input-group mb-3">
        <button class="btn btn-outline-primary" type="button">User</button>
        <input type="text" class="form-control" placeholder="Some text">
    </div>

    <div class="input-group mb-3">
        <input type="text" class="form-control" placeholder="Search">
        <button class="btn btn-success" type="submit">Search</button>
    </div>

    <div class="input-group mb-3">
        <input type="text" class="form-control" placeholder="Something clever..">
        <button class="btn btn-danger" type="button">Send Message</button>
    </div>
</div>
</div>