function afterRequest(response) {
	// TODO create the DOM from the response data

}

// Request a GET on this URL : https://jsonplaceholder.typicode.com/users
// then : callback the function afterRequest

