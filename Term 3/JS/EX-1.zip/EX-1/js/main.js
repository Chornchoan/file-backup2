function randomWord() {
    // todo 
}

const textElement = document.querySelector('.text');
const output = document.querySelector('#output');
// todo 


setInterval(randomWord, 1000);