const removePoster = (event) => {
   
}


// Main 
