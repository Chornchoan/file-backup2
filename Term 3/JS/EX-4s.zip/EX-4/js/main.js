
const viewImage = (event) => {

}


// Main 
const posters = document.querySelectorAll('.poster');
const right = document.querySelector('.right');
