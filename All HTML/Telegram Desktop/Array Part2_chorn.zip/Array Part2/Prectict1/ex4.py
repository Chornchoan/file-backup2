# Ex4 - Array pop() function

array = [1, 2, 5, 7, 9, 7, 4, 8]

    #1 - Remove number 3 from list
# for i in range(len(array)):
#     if array[i]==3:
#         array.pop(i)
# print(array)

    #2 - Remove first 7 from list
# i=0
# isSeven =True
# while i < (len(array)) and isSeven:
#     if array[i]!=7:
#         array.pop(i)
#     else:
#         isSeven=False
# print(array)
    

#3 - Remove only odd number from list
# i=0
# isodd=True
# while i <(len(array))and isodd:
#     if array[i]%2==0:
#         array.append(array[i])
#     else:
#         isodd=False
#     i+=1
# print(array)

    #4 - Remove only value < 5 from list
# array2 = []
# for i in  range (len(array)):
#     if array[i] >= 5:
#         array2.append(array[i])
# print(array2)