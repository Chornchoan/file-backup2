# Ex1 - String array
Text = "How are you?"

#1 - Display word by word from text
#   How
#   are
#   you?
#2 - Create new array from text seperate by space
["How","are","you?"]