# Ex2 - basic 2
arr = [2, 3, 4, 3, 2, 5, 3, 2, 5]

    #1 - Square odd number in list
# for i in range(len(arr)):
#     if arr[i]%2!=0:
#         arr[i]*=arr[i]
# print(arr)
    #2 - Filter list with dupplicate value
# output: [2, 3, 4, 5]
# for i in range(len(arr)):
#     for j  in range(len(arr)):
#         if arr[i][j]==(arr[i]):
#             arr.pop(i)
# print(arr)    ///<This code not alraedy>////