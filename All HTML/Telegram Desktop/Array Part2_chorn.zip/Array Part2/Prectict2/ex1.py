# Ex1 - basic 1
arr = ["banana","apple"]

#1 - How many "a" or "A" in list
# array =0
# for i in range(len(arr)):
#     for j in range(len(arr[i])):
#         if arr[i][j]=="a":
#             array+=1
# print(array)
#2 - Create new array store letter difference from A
# Output: ["b", "n", "n", "p", "p", "l", "e"]
# array=[]
# for i in range(len(arr)):
#     for j in range(len(arr[i])):
#         if arr[i][j]!="a":
#             array+=arr[i][j]
# print(array)