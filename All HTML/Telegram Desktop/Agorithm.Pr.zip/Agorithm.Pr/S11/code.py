# # EX1
# n1 = int(input())
# n2 = int(input())
# sum = -1
# if n2 > n1:
#     sum = n2
# print(sum)

# EX2
# text = input()
# res = ""
# for i in range(len(text)):
#     if text[i].upper() =="A":
#         res= "True"
#     else:
#         res = "False"
# print(res)
# EX3
# 2 3 4 end 2:4:

# isfound=True
# result=""
# text=input()
# while isfound:
#       if text!="end" :
#             if int(text)%2==0:
#                   result+=text+":"
#             text=input()
#       else:
#             if text=="end":
#                   isfound=False
# print(result[:-1])

# # #  EX4
# text = input()
# res = 0
# sum = False
# i =0 
# while i+1<len(text):
#       if text[i]+text[i+1]=="KK":
#             res = i
#       i+=1
# print(res)
# # EX4
# text = input()
# res = -1
# i =0
# isnum = False
# while i+1<len(text) and not isnum:
#       if text[-(i)] + text[-(i+1)] == "KK":
#             res = len(text) - (i+1)
#             isnum=True
#       i +=1
# print(res)
###############EX5
# text = input()
# isfound = False
# result1 = ""
# result2 = ""
# result = 0
# for i in range(len(text)):
#     if text[i] != ";" and not isfound :
#         result1 += text[i]
#     else:
#         isfound = True
#         if isfound and text[i] != ";":
#             result2 += text[i]
# if isfound and True:
#     result += int(result1) + int(result2)
#     print(result)
# else:
#     print("wrong format")


     

# # play-code
# text = "JONH IS A BOY SMOS IN THE WORLD!"
# res = ""
# for i in range(len(text)):
#       if text[i]!=" ":
#             res +=text[i]
#       else:
#             res +="\n"
# print(res)

# PR1
