# n = int(input())
# inRange = False
# if n >= 1 and n <= 10:
#     inRange = True
# elif n >= 29 and n <= 51:
#     inRange = True
# elif n >= 76 and n <= 101:
#     inRange = True
# print(inRange)


number = int(input())
isFound = False
if number >= 1 and number <= 10:
    isFound = True
elif number >=29 and number <= 51:
    isFound = True
elif number >= 76 and number <= 101:
    isFound = True
print(isFound)