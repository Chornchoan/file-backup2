text = input()
resulta = 0
resultb = 0
for i in range(len(text)):
    if text[i] == "A" or text[i] == "a":
        resulta =10
    elif text[i]== "B" or text[i] == "b":
        resultb =20
print(resulta+resultb)