# text = input()
# word = ""
# isFound = False
# for i in range(len(text)):
#     if text[i] ==" " or i == len(text) -1:
#         if i == len(text) -1:
#             word += text[i]
#         if word.upper() == "RADY": 
#             isFound = True       
#         word = ""    
#     else:
#         word +=text[i]
# if isFound:
#      print("yes")
# else:
#      print("No")
     
# EX3
