# EX1
# text = input()
# res = "NOT SORTED"
# for i in range(len(text)):
#     if text[0]<text[i]:
#         res ="SORTED"
#     elif text[0]==text[i]:
#         res="SORTED"
#     else:
#         res="NOT SORTED"
# print(res)
        
# # EX2####################
# text = input()
# res=""
# isabc =False
# i = 0
# while not isabc and i +2 < len(text):
#     if text[i].upper() + text[i + 1].upper() + text[i + 2].upper() =="ABC":
#         res = "OK"
#     else:
#         isabc = True
#         res = "WRONG"
#     i += 1
# print(res)
 
# EX3###################
# text = input()
# is_wrong_display =False
# result =''
# for i in range(len(text)):
#     if text[i] =='x':
#         result = 'OK'
#     elif i+1<len(text) and text[i] == '[' and text[i+1] == 'y':
#         result ='OK'
#     elif i+1<len(text) and text[i] == 'y' and (text[i+1] ==']' or text[i+1] =='y') and i !=0 and text[i-1] !='x':
#         result ='OK'
#     elif text[i] ==']' and text[i-1] =='y':
#         result ='OK'
#     else:
#         is_wrong_display = True
# if is_wrong_display:
#     print("WRONG")
# else:
#     print(result)
    