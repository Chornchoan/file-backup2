# EX1
# text = input()
# sum = 0
# for i in range(len(text)):
#     if text[i].upper()=="A" and text[i+1].upper()=="B" and  text[i +2].upper()=="C":
#         sum +=1
# print(sum)

# # EX2
# word = input()
# i = 0
# mult = 1 
# while i< len(word) and int(word[i]) !=6:
#     mult *=int(word[i])
#     i += 1
# print(mult)
# EX3
# number = int(input())
# result = ""
# for index in range(number):
#    result = result + " " + str(index + 1)
# print(result)
