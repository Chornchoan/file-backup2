# text = input()
# i = 0
# isFound = False
# indexofo = None
# while  i < len(text):
#     if text[i] =="O" or text[i]=="o":
#         isFound =True
#         indexofo = i
#     i += 1
# if isFound:
#     print(indexofo)
# else:
#     print(-1)


