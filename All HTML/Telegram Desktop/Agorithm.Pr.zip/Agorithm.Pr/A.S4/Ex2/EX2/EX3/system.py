# text = input()
# text2 = input()
# word = 0
# # n = text + text2
# for i in range(len(text)):
#     if text[i].isupper():
#         word += 1
# for i in range(len(text2)):
#     if text[i].isupper():
#         word += 1
# print(word)


text = input()

