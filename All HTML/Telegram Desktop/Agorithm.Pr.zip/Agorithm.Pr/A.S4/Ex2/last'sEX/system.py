# text = input()
# index = -1 
# for i in range(len(text)):
#     if text[i] == "k" or text[i] == "K":
#         index = i
# print(index)
