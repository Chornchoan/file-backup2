# Ex1
# string = input()
# res = False
# for i in range(len(string)):
#     if string[i] == "7":
#         res = True
# print(res)
